import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmployeeDetails } from "./employeeDetails";

function EmployeeCount() {
  const navigate = useNavigate();

  // State
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  // Valid employees
  const validEmployees = EmployeeDetails.filter(emp => emp.employeeId);

  // Combined filtering
  const filteredEmployees = validEmployees.filter(emp => {
    const matchesName =
      emp.fullName.toLowerCase().includes(search.toLowerCase());

    const matchesGender =
      genderFilter ? emp.gender === genderFilter : true;

    const matchesStatus =
      statusFilter === ""
        ? true
        : statusFilter === "active"
        ? emp.isActive
        : !emp.isActive;

    return matchesName && matchesGender && matchesStatus;
  });

  // Counts
  const totalCount = filteredEmployees.length;
  const activeCount = filteredEmployees.filter(e => e.isActive).length;
  const inactiveCount = filteredEmployees.filter(e => !e.isActive).length;

  // Handlers
  const handleAdd = () => {
    navigate("/employee/add");
  };

  const handleEdit = (employeeId) => {
    navigate(`/employee/edit/${employeeId}`);
  };

  const handleDelete = (emp) => {
    const confirmDelete = window.confirm(
      `Are you sure you want to delete ${emp.fullName}?`
    );
    if (confirmDelete) {
      alert(`Deleted ${emp.fullName}`);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center" }}>Employee Management</h2>

      {/* Toolbar */}
      <div style={toolbar}>
        <input
          type="text"
          placeholder="Search by Name"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />

        <select value={genderFilter} onChange={e => setGenderFilter(e.target.value)}>
          <option value="">All Genders</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </select>

        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>

        <button style={btn} onClick={handleAdd}>+ Add Employee</button>
        <button style={btn} onClick={handlePrint}>Print</button>
      </div>

      {/* Summary */}
      <div style={summaryStyle}>
        <div><strong>Total:</strong> {totalCount}</div>
        <div style={{ color: "green" }}>
          <strong>Active:</strong> {activeCount}
        </div>
        <div style={{ color: "red" }}>
          <strong>Inactive:</strong> {inactiveCount}
        </div>
      </div>

      {/* Table */}
      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>Employee ID</th>
            <th style={thStyle}>Profile</th>
            <th style={thStyle}>Full Name</th>
            <th style={thStyle}>Gender</th>
            <th style={thStyle}>DOB</th>
            <th style={thStyle}>State</th>
            <th style={thStyle}>Active</th>
            <th style={thStyle}>Actions</th>
          </tr>
        </thead>

        <tbody className="table-body">
          {filteredEmployees.map(emp => (
            <tr
              key={emp.employeeId}
              style={{ backgroundColor: emp.isActive ? "#e8f9e8" : "transparent" }}
            >
              <td>{emp.employeeId}</td>

              <td>{emp.gender.toLowerCase() === "male" ? "👦 " : "👧 "}</td>

              <td>{emp.fullName}</td>
              <td>{emp.gender}</td>
              <td>{emp.dateOfBirth}</td>
              <td>{emp.state}</td>

              <td align="center">
                <input type="checkbox" checked={emp.isActive} readOnly />
              </td>

              <td>
                <button style={btn} onClick={() => handleEdit(emp.employeeId)}>
                  Edit
                </button>
                <button style={deleteBtn} onClick={() => handleDelete(emp)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}

          {filteredEmployees.length === 0 && (
            <tr>
              <td colSpan="8" style={{ textAlign: "center", padding: "15px" }}>
                No employees found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

/* Styles */
const toolbar = {
  display: "flex",
  gap: "10px",
  marginBottom: "15px"
};

const summaryStyle = {
  display: "flex",
  justifyContent: "center",
  gap: "30px",
  marginBottom: "15px",
  fontSize: "16px"
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse"
};

const thStyle = {
  border: "1px solid #ccc",
  padding: "10px",
  backgroundColor: "#f5f5f5"
};

const tdStyle = {
  border: "1px solid #ccc",
  padding: "10px",
  textAlign: "center"
};

const btn = {
  padding: "6px 10px",
  cursor: "pointer"
};

const deleteBtn = {
  ...btn,
  backgroundColor: "#ffdddd",
  border: "1px solid #ff9999"
};

export default EmployeeCount;

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext"; // Adjust path if needed
import "./employeeDetails.css";

const usersData = [
  { username: "admin", password: "Admin@123" },
  { username: "john_doe", password: "John@1234" },
  { username: "jane_smith", password: "Jane@5678" },
  { username: "admin", password: "Admin@2026" },
  { username: "helloWorld", password: "Hello@123" },
];

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth(); // Get login function from context

  const handleSubmit = (e) => {
    e.preventDefault();

    const trimmedUsername = username.trim();
    const trimmedPassword = password.trim();

    if (!trimmedUsername || !trimmedPassword) {
      setError("Please fill in all fields");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const user = usersData.find(
        (u) =>
          u.username.toLowerCase() === trimmedUsername.toLowerCase() &&
          u.password === trimmedPassword
      );

      if (user) {
        setError("");
        login(); // Set authenticated state
        navigate("/dashboard");
      } else {
        setError("Invalid username or password");
        setLoading(false);
      }
    }, 800);
  };

  // Rest of your JSX remains the same
  return (
    <div className="login-container">
      <span className="login-section">
        <h1>🙂 </h1>
        <h1> Welcome to Dashboard! </h1>
      </span>

      <span className="login-component">
        <h1>Employee Login Portal </h1>
        <form onSubmit={handleSubmit} className="login-form">
          <div className="username-details">
            <label htmlFor="username">Username or Email:</label>
            <input
              id="username"
              type="text"
              placeholder="Enter your username or email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="password-details">
            <label htmlFor="password">Password:</label>
            <input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && <div className="login-error">{error}</div>}

          <div className="submission">
            <button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <span className="spinner"></span> Logging in...
                </>
              ) : (
                "Login"
              )}
            </button>
            <button
              type="button"
              onClick={() => {
                setUsername("");
                setPassword("");
                setError("");
              }}
            >
              Reset
            </button>
          </div>
        </form>
      </span>
    </div>
  );
}

export default Login;

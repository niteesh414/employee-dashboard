// Dashboard.jsx
import EmployeeCount from "./EmployeeCount";

function Dashboard() {
  return (
    <div>
      <h1>Welcome to the Dashboard</h1>
      <EmployeeCount />
      {/* Other content */}
    </div>
  );
}

export default Dashboard;
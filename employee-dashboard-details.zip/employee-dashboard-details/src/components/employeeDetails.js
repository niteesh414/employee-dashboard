export const EmployeeDetails = [
  {
    "employeeId": "EMP001",
    "profileImage": "",
    "fullName": "Aarav Sharma",
    "gender": "Male",
    "dateOfBirth": "1990-05-15",
    "state": "Maharashtra",
    "isActive": true
  },
  {
    "employeeId": "EMP002",
    "profileImage": "",
    "fullName": "Priya Patel",
    "gender": "Female",
    "dateOfBirth": "1992-08-22",
    "state": "Gujarat",
    "isActive": true
  },
  {
    "employeeId": "EMP003",
    "profileImage": "",
    "fullName": "Rahul Kumar",
    "gender": "Male",
    "dateOfBirth": "1988-11-03",
    "state": "Delhi",
    "isActive": false
  },
  {
    "employeeId": "EMP004",
    "profileImage": "",
    "fullName": "Ananya Singh",
    "gender": "Female",
    "dateOfBirth": "1995-02-28",
    "state": "Uttar Pradesh",
    "isActive": true
  },
  {
    "employeeId": "EMP005",
    "profileImage": "",
    "fullName": "Vikram Reddy",
    "gender": "Male",
    "dateOfBirth": "1993-07-19",
    "state": "Telangana",
    "isActive": true
  },
  {
    "employeeId": "EMP006",
    "profileImage": "",
    "fullName": "Sanya Mehta",
    "gender": "Female",
    "dateOfBirth": "1991-12-12",
    "state": "Punjab",
    "isActive": false
  },
  {
    "employeeId": "EMP007",
    "profileImage": "",
    "fullName": "Arjun Nair",
    "gender": "Male",
    "dateOfBirth": "1989-04-05",
    "state": "Kerala",
    "isActive": true
  },
  {
    "employeeId": "EMP008",
    "profileImage": "",
    "fullName": "Ishita Joshi",
    "gender": "Female",
    "dateOfBirth": "1994-09-30",
    "state": "Rajasthan",
    "isActive": true
  },
  {
    "employeeId": "EMP009",
    "profileImage": "",
    "fullName": "Rohan Bose",
    "gender": "Male",
    "dateOfBirth": "1992-01-17",
    "state": "West Bengal",
    "isActive": false
  },
  {
    "employeeId": "EMP010",
    "profileImage": "",
    "fullName": "Neha Kapoor",
    "gender": "Female",
    "dateOfBirth": "1996-06-25",
    "state": "Haryana",
    "isActive": true
  }
];
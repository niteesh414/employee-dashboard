import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { EmployeeDetails } from "./employeeDetails";

const STATES = [
  "Maharashtra",
  "Gujarat",
  "Delhi",
  "Uttar Pradesh",
  "Telangana",
  "Punjab",
  "Kerala",
  "Rajasthan",
  "West Bengal",
  "Haryana"
];

function EmployeeForm() {
  const { employeeId } = useParams();
  const navigate = useNavigate();

  const isEdit = Boolean(employeeId);
  const existingEmployee = EmployeeDetails.find(
    emp => emp.employeeId === employeeId
  );

  const [formData, setFormData] = useState({
    fullName: "",
    gender: "",
    dateOfBirth: "",
    state: "",
    isActive: true,
    profileImage: ""
  });

  const [imagePreview, setImagePreview] = useState("");
  const [errors, setErrors] = useState({});

  /* Prefill data for Edit */
  useEffect(() => {
    if (isEdit && existingEmployee) {
      setFormData(existingEmployee);
      setImagePreview(existingEmployee.profileImage);
    }
  }, [isEdit, existingEmployee]);

  /* Handle input change */
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  /* Handle image upload */
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const imageURL = URL.createObjectURL(file);
    setImagePreview(imageURL);
    setFormData(prev => ({ ...prev, profileImage: imageURL }));
  };

  /* Form validation */
  const validateForm = () => {
    const newErrors = {};

    if (!formData.fullName.trim()) newErrors.fullName = "Full Name is required";
    if (!formData.gender) newErrors.gender = "Gender is required";
    if (!formData.dateOfBirth) newErrors.dateOfBirth = "DOB is required";
    if (!formData.state) newErrors.state = "State is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /* Submit */
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    if (isEdit) {
      alert("Employee updated successfully");
    } else {
      alert("Employee added successfully");
    }

    navigate("/");
  };

  return (
  <div className="employee-form-container">
    <h2>{isEdit ? "Edit Employee" : "Add Employee"}</h2>

    <form onSubmit={handleSubmit}>
      {/* Full Name */}
      <div className="form-field">
        <label>Full Name</label>
        <input
          name="fullName"
          type="text"
          value={formData.fullName}
          onChange={handleChange}
        />
        {errors.fullName && <span className="error-text">{errors.fullName}</span>}
      </div>

      {/* Gender */}
      <div className="form-field">
        <label>Gender</label>
        <select name="gender" value={formData.gender} onChange={handleChange}>
          <option value="">Select</option>
          <option>Male</option>
          <option>Female</option>
        </select>
        {errors.gender && <span className="error-text">{errors.gender}</span>}
      </div>

      {/* DOB */}
      <div className="form-field">
        <label>Date of Birth</label>
        <input
          type="date"
          name="dateOfBirth"
          value={formData.dateOfBirth}
          onChange={handleChange}
        />
        {errors.dateOfBirth && <span className="error-text">{errors.dateOfBirth}</span>}
      </div>

      {/* Profile Image */}
      <div className="form-field">
        <label>Profile Image</label>
        <input type="file" accept="image/*" onChange={handleImageChange} />
        {imagePreview && (
          <img src={imagePreview} alt="Preview" className="profile-preview" />
        )}
      </div>

      {/* State */}
      <div className="form-field">
        <label>State</label>
        <select name="state" value={formData.state} onChange={handleChange}>
          <option value="">Select State</option>
          {STATES.map(state => (
            <option key={state}>{state}</option>
          ))}
        </select>
        {errors.state && <span className="error-text">{errors.state}</span>}
      </div>

      {/* Active Status */}
      <div className="form-field checkbox-field">
        <input
          id="active-checkbox"
          type="checkbox"
          name="isActive"
          checked={formData.isActive}
          onChange={handleChange}
        />
        <label htmlFor="active-checkbox">Active</label>
      </div>

      {/* Buttons */}
      <div className="button-group">
        <button type="submit" className="btn btn-submit">
          {isEdit ? "Update" : "Save"}
        </button>
        <button type="button" className="btn" onClick={() => navigate("/")}>
          Cancel
        </button>
      </div>
    </form>
  </div>
);
}

export default EmployeeForm;
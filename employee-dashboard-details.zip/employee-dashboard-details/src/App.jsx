// App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import ProtectedRoute from "./components/ProtectedRoute";
import EmployeeCount from "./components/EmployeeCount";
import EmployeeForm from "./components/EmployeeForm";

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<Dashboard />} />
          {/* Add other protected routes here */}
        </Route>

        {/* Redirect root to login */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/" element={<EmployeeCount />} />
        <Route path="/employee/edit/:employeeId" element={<EmployeeForm />} />
        <Route path="/employee/add" element={<EmployeeForm />} />
      </Routes>
    </AuthProvider>
  );
}

export default App;